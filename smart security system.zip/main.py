from machine import Pin, time_pulse_us
import time

# Define sensor and output pins
pir_pin = Pin(12, Pin.IN)             # PIR Motion Sensor pin
trig_pin = Pin(13, Pin.OUT)           # HC-SR04 Ultrasonic Trig pin
echo_pin = Pin(14, Pin.IN)            # HC-SR04 Ultrasonic Echo pin
led_pin = Pin(25, Pin.OUT)            # LED pin
buzzer_pin = Pin(26, Pin.OUT)         # Buzzer pin

# Define proximity threshold (in centimeters)
proximity_threshold = 20              # Trigger if object is closer than 20 cm

# Initialize LED and Buzzer to be off initially
led_pin.value(0)
buzzer_pin.value(0)

def get_ultrasonic_distance():
    # Send a 10us pulse to trigger the ultrasonic sensor
    trig_pin.value(0)
    time.sleep_us(2)
    trig_pin.value(1)
    time.sleep_us(10)
    trig_pin.value(0)

    # Measure the duration of the echo pulse
    duration = time_pulse_us(echo_pin, 1)
    
    # Calculate distance in centimeters
    distance = (duration * 0.0343) / 2  # Speed of sound is approximately 343 m/s
    return distance

while True:
    # Read PIR motion sensor
    motion_detected = pir_pin.value()
    
    # Read distance from ultrasonic sensor
    distance = get_ultrasonic_distance()
    
    # Check if motion is detected or proximity threshold is met
    if motion_detected == 1 or distance < proximity_threshold:
        # Trigger alarm
        led_pin.value(1)              # Turn on LED
        buzzer_pin.value(1)           # Turn on Buzzer
        
        print("ALERT: Motion or proximity detected!")
        print("Distance:", distance, "cm")
        
        # Delay to keep alert on for a bit
        time.sleep(1)
    else:
        # Turn off alert
        led_pin.value(0)              # Turn off LED
        buzzer_pin.value(0)           # Turn off Buzzer
        print("No motion. LED and Buzzer are OFF")
    
    # Short delay before repeating
    time.sleep(0.2)

    